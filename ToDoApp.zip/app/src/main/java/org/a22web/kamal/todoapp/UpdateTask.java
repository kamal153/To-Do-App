package org.a22web.kamal.todoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateTask extends AppCompatActivity {

    EditText uname,uinfo;
    String id;
    DbAdapter db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_task);

        id=getIntent().getStringExtra("ID");
        uname=(EditText)findViewById(R.id.uname);
        uinfo=(EditText)findViewById(R.id.uinfo);
        db=new DbAdapter(this);
        db.open();

        Cursor raw=db.fetchTaskById(id);
        uname.setText(raw.getString(raw.getColumnIndexOrThrow("name")));
        uinfo.setText(raw.getString(raw.getColumnIndexOrThrow("info")));

        findViewById(R.id.uup).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(uname.getText().toString().isEmpty() || uinfo.getText().toString().isEmpty())
                    Toast.makeText(UpdateTask.this,"Enter both task name and info",Toast.LENGTH_LONG).show();
                else {
                    db.updateTask(id, uname.getText().toString(), uinfo.getText().toString());
                    Toast.makeText(UpdateTask.this,"Task updated successfully",Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(UpdateTask.this, ViewTask.class);
                    intent.putExtra("ID",id);
                    (UpdateTask.this).finish();
                    intent.setFlags( Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NO_HISTORY);
                    startActivity(intent);
                }
            }
        });
    }

    public void onBackPressed()
    {
        Intent intent = new Intent(UpdateTask.this, ViewTask.class);
        intent.putExtra("ID",id);
        (UpdateTask.this).finish();
        intent.setFlags( Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NO_HISTORY);
        startActivity(intent);
    }
}
