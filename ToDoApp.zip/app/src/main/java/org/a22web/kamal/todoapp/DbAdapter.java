package org.a22web.kamal.todoapp;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class DbAdapter {

    //define static variable
    public static int dbversion =6;
    public static String dbname = "ToDoAPP";

    private static class DatabaseHelper extends SQLiteOpenHelper {
        public DatabaseHelper(Context context) {
            super(context,dbname,null, dbversion);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("create table if not exists todo(_id INTEGER PRIMARY KEY autoincrement,name VARCHAR(25),info VARCHAR(512))");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("drop table todo");
            onCreate(db);
        }
    }

    //establsh connection with SQLiteDataBase
    private final Context c;
    private DatabaseHelper dbHelper;
    private SQLiteDatabase sqlDb;

    public DbAdapter(Context context) {
        this.c = context;
    }

    public DbAdapter open() throws SQLException {
        dbHelper = new DatabaseHelper(c);
        sqlDb = dbHelper.getWritableDatabase();
        return this;
    }

    public Cursor fetchTask()
    {
        Cursor row=sqlDb.rawQuery("SELECT _id,name,SUBSTR(info, 1, 40) As info FROM todo",null);
        if(row!=null)
            row.moveToFirst();
        return row;
    }

    public Cursor fetchTaskById(String id)
    {
        Cursor row=sqlDb.rawQuery("SELECT * FROM todo where _id="+id,null);
        if(row!=null)
            row.moveToFirst();
        return row;
    }

    public void insertTask(String s1,String s2)
    {
        sqlDb.execSQL("insert into todo(name,info) values ('"+s1+"','"+s2+"')");
    }

    public void deleteTask(String s1)
    {
        sqlDb.execSQL("delete from todo where _id="+s1);
    }

    public void updateTask(String s1,String s2,String s3)
    {
        sqlDb.execSQL("update todo set name='"+s2+"' , info='"+s3+"' where _id="+s1);
    }

}