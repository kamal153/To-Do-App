package org.a22web.kamal.todoapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AddTask extends AppCompatActivity {

    EditText aname,ainfo;
    DbAdapter db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        aname=(EditText)findViewById(R.id.aname);
        ainfo=(EditText)findViewById(R.id.ainfo);
        db=new DbAdapter(this);
        db.open();

        findViewById(R.id.aadd).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(aname.getText().toString().isEmpty() || ainfo.getText().toString().isEmpty())
                    Toast.makeText(AddTask.this,"Enter the task name and info",Toast.LENGTH_LONG).show();
                else
                {
                    db.insertTask(aname.getText().toString(),ainfo.getText().toString());
                    Toast.makeText(AddTask.this,"Task inserted successfully",Toast.LENGTH_LONG).show();
                    startActivity(new Intent(AddTask.this,MainActivity.class));
                }
            }
        });
    }

    public void onBackPressed()
    {
        Intent intent = new Intent(AddTask.this, MainActivity.class);
        (AddTask.this).finish();
        intent.setFlags( Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NO_HISTORY);
        startActivity(intent);
    }
}
