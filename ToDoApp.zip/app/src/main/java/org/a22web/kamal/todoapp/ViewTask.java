package org.a22web.kamal.todoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class ViewTask extends AppCompatActivity {

    TextView vname,vinfo;
    DbAdapter db;
    String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_task);

        db=new DbAdapter(this);
        db.open();
        vname=(TextView)findViewById(R.id.vname);
        vinfo=(TextView)findViewById(R.id.vinfo);

        Intent intent=getIntent();
        id=intent.getStringExtra("ID");
        Cursor raw=db.fetchTaskById(id);

        vname.setText(raw.getString(raw.getColumnIndexOrThrow("name")));
        vinfo.setText(raw.getString(raw.getColumnIndexOrThrow("info")));

        findViewById(R.id.vdel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db.deleteTask(id);
                Toast.makeText(ViewTask.this,"Task deleted successfully",Toast.LENGTH_LONG).show();
                Intent intent = new Intent(ViewTask.this, MainActivity.class);
                (ViewTask.this).finish();
                intent.setFlags( Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NO_HISTORY);
                startActivity(intent);
            }
        });

        findViewById(R.id.vup).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ViewTask.this, UpdateTask.class);
                intent.putExtra("ID",id);
                startActivity(intent);
            }
        });

    }
    public void onBackPressed()
    {
        Intent intent = new Intent(ViewTask.this, MainActivity.class);
        (ViewTask.this).finish();
        intent.setFlags( Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NO_HISTORY);
        startActivity(intent);
    }
}
