package org.a22web.kamal.todoapp;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.ListView;
import android.os.Bundle;
import android.database.Cursor;
import android.widget.SimpleCursorAdapter;
import android.widget.AdapterView;
import android.content.Intent;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    DbAdapter db;
    ListView lv;
    SimpleCursorAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DbAdapter(this);
        db.open();

        findViewById(R.id.add).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,AddTask.class));
            }
        });

        lv= (ListView) findViewById(R.id.list);
        int[] xml_id = new int[] {
                R.id.lname,
                R.id.linfo
        };
        String[] column = new String[] {
                "name",
                "info"
        };
        Cursor row = db.fetchTask();
        adapter = new SimpleCursorAdapter(this, R.layout.liststyle,row,column, xml_id, 0);
        lv.setAdapter(adapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterview, View view, int position, long id) {
                Cursor row = (Cursor) adapterview.getItemAtPosition(position);

                String _id = row.getString(row.getColumnIndexOrThrow("_id"));
                //go to detailsContact page
                Intent todetais = new Intent(MainActivity.this, ViewTask.class);
                todetais.putExtra("ID",_id);
                startActivity(todetais);
            }
        });
    }


}
